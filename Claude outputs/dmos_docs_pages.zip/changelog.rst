Changelog
=========

This page will track notable changes once the repository is released as a
versioned, citable package.

.. note::

   **TODO:** start versioning (e.g. ``v1.0``) when preparing the methodology
   paper, archive the release on Zenodo for a DOI, and record changes here using
   the ``Added`` / ``Changed`` / ``Fixed`` headings below.

Unreleased
----------

Added
~~~~~

- Documentation site scaffold (Overview, User guide, Examples, API reference).
