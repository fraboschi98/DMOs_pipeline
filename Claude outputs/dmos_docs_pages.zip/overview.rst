Overview
========

DMOs Pipeline processes bilateral foot-mounted IMU recordings and turns
stride-level gait data into standardized Digital Mobility Outcomes (DMOs) for
physical-activity monitoring (PAM) in free-living conditions.

Pre-existing algorithms for extracting gait parameters are validated on
scripted tasks in controlled environments. This pipeline extends their use to
real-world data: the stride-level parameters are extracted by an already
validated algorithm (e.g. `gaitmap`), and the added value here is the
standardized identification of walking bouts and the aggregation of parameters
into DMOs, following the Mobilise-D framework.

What the pipeline provides
--------------------------

* gaitmap-based gait processing of raw bilateral foot IMU signals;
* stride-level temporal and spatial parameter extraction;
* recording- and wearing-time estimation;
* event- and stride-level quality control (labelling, without removing rows);
* walking-bout identification with pauses and signal breaks;
* walking-bout-, day-, and week-level aggregated DMOs;
* complexity metrics of the daily physical-activity-state sequence;
* structured CSV and JSON outputs and diagnostic figures.

Outputs are provided at three levels: spatiotemporal micro-parameters,
macro-parameters / complexity metrics, and day/week summaries of the
micro-parameters.

Installation
------------

.. note::

   DMOs Pipeline is currently distributed as a **repository**, not as a
   published package. Clone it and install its dependencies into a dedicated
   environment.

Clone the repository:

.. code-block:: bash

   git clone https://github.com/fraboschi98/DMOs_pipeline.git
   cd DMOs_pipeline

Create and activate an environment (conda shown here), then install the
dependencies:

.. code-block:: bash

   conda create -n dmos python=3.11
   conda activate dmos
   pip install -r requirements.txt

The pipeline relies on `gaitmap` and `gaitmap_mad` for the gait-processing
stage; see ``requirements.txt`` for the full list.

.. note::

   A citable, versioned release (e.g. a tagged ``v1.0`` archived on Zenodo with
   a DOI, or a ``pip``-installable package published on PyPI) is planned so that
   readers can install exactly the version used in the paper. See the
   :doc:`changelog`.

License and citation
--------------------

.. note::

   **TODO:** add the license and, once the methodology paper is published, the
   citation and DOI here and in the sidebar ``icon_links``.
