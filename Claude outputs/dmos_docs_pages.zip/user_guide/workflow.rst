Workflow
========

The pipeline turns raw bilateral foot-worn IMU data into standardized DMOs
through a sequence of stages. Stride-level gait events and parameters are
produced by an already-validated algorithm; the pipeline then identifies
walking bouts and aggregates the parameters.

High-level flow
---------------

.. code-block:: text

   raw foot-worn IMU
        |
        v
   gait algorithm (e.g. gaitmap)  ->  events + stride-level parameters
        |
        v
   DMOs Pipeline
        |-- quality check (event + parameter labels)
        |-- walking-bout identification (pauses, breaks, valid WBs)
        |-- WB-level aggregation
        |-- day-level aggregation
        |-- week-level complexity
        |
        v
   standardized PAM DMOs (micro, macro, day/week summaries)

Processing stages and classes
-----------------------------

.. list-table::
   :header-rows: 1
   :widths: 28 32 40

   * - Stage
     - Class
     - Role
   * - Gait processing
     - :class:`~dmos_pipeline.gaitmap_pipeline.GaitMapPipeline`
     - Filter the signal, run gaitmap, estimate recording/wearing time, export
       events and stride-level parameters.
   * - Quality control
     - :class:`~dmos_pipeline.quality_check.QualityCheck`
     - Add event- and parameter-level quality labels without removing rows.
   * - Walking-bout extraction
     - :class:`~dmos_pipeline.wb_pipeline.WBpipeline`
     - Detect pauses and breaks, split into segments, label valid WBs.
   * - Data collection
     - :class:`~dmos_pipeline.csv_collector.Collector`
     - Collect per-session CSV/JSON outputs for one patient across dates.
   * - WB-level analysis
     - :class:`~dmos_pipeline.wb_analyzer.WalkingBouts_analyzer`
     - Link strides to WBs, add cadence / PA labels, aggregate to WB-level
       averages.
   * - Day-level analysis
     - :class:`~dmos_pipeline.day_analyzer.DayLevel_analyzer`
     - Aggregate WB-level data into one row per patient and day.
   * - Complexity
     - :class:`~dmos_pipeline.complexity_analyzer.PAComplexity_analyzer`
     - Build the daily PA-state series and compute Hn, LZC, PLZC and weekly
       SampEn.
   * - Visualization
     - :class:`~dmos_pipeline.kde_plotter.KDEPlotter`,
       :class:`~dmos_pipeline.pause_plotter.PausePlotter`
     - KDE distributions of WB-level parameters; diagnostic pause plots.

.. note::

   **TODO:** replace the ASCII diagram above with the pipeline flowchart from
   the slides (class blocks). Add it to ``docs/_static/`` and reference it, e.g.::

      .. image:: ../_static/pipeline_flowchart.png
         :alt: DMOs Pipeline workflow
         :align: center
