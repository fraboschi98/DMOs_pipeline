Definitions and thresholds
==========================

The pipeline identifies walking bouts from the temporal structure of detected
gait events, and separates genuine within-walking pauses from short signal
breaks. This page defines the terms used throughout the documentation and lists
the default thresholds.

.. important::

   All thresholds below are **default configuration values** taken from the
   example scripts. They are passed through the ``config`` dictionaries of the
   corresponding classes and can be overridden per run. Some are grounded in the
   Mobilise-D / gait literature; others were introduced specifically to handle
   one-foot recordings and are marked as such.

Core terms
----------

Stride
   A single gait cycle for one foot, bounded by consecutive initial-contact
   events, with its associated temporal and spatial parameters.

Segment
   A candidate walking period obtained by splitting the recording at detected
   pauses. Left and right stride IDs are assigned to each segment, and
   validity rules are then applied to decide whether it qualifies as a walking
   bout.

Walking bout (WB)
   A valid segment that satisfies the configured stride-count rules, following
   the Mobilise-D walking-bout definition. The pipeline handles both one-foot
   and two-foot segments.

Pause
   A period in which gait events are absent from **both** feet simultaneously
   for longer than the pause threshold. Pauses split the recording into
   segments.

Signal break
   A shorter simultaneous no-event interval, below the pause threshold. Breaks
   are retained within segments rather than splitting them.

Walking-bout detection thresholds
---------------------------------

From the ``wb_config`` used in :doc:`../examples/gaitmap_quality_check`:

.. list-table::
   :header-rows: 1
   :widths: 40 20 40

   * - Parameter
     - Default
     - Meaning
   * - ``wb_pause_s_threshold``
     - ``3.0`` s
     - Simultaneous no-event interval at or above this is a **pause**; below it,
       a **signal break**.
   * - ``threshold_two_sides``
     - ``5`` strides
     - Minimum strides for a valid WB when both feet contribute
       (Mobilise-D-inspired).
   * - ``threshold_one_side``
     - ``3`` strides
     - Minimum strides for a valid WB when only one foot is available
       (**pipeline-specific**, introduced for one-foot segments).
   * - ``use_only_quality_checked_events``
     - ``True``
     - If True, events failing the event-level quality check are excluded before
       WB extraction.
   * - ``event_quality_column``
     - ``quality_check(IC<0)``
     - Column used to read the event-level quality label.

.. note::

   Because quality-failed events can be removed *before* WB identification, WB
   boundaries and durations are affected by the quality check. For a
   better-estimated WB duration one may run WB identification on all events
   (no event filtering), and apply the quality check only at the aggregation
   stage so that the DMO values remain reliable. This keeps both a well-estimated
   duration and stable parameter values.

Quality-control rules
---------------------

From the ``quality_check_config`` used in the same example. The quality check
**labels** rows; it does not delete them.

Event-level check
   The filtered gyroscope signal (``gyr_ml`` by default, Butterworth low-pass,
   cutoff ``5.0`` Hz, order ``4``) is read at each initial-contact sample on the
   corresponding foot sensor. An event is labelled as failing when the filtered
   value at initial contact is **greater than** ``ic_threshold`` (default
   ``0.0``). Left-foot events are checked on ``left_sensor``, right-foot events
   on ``right_sensor``.

Parameter-level check
   Stride-level parameters are checked against plausibility rules. A stride
   fails when at least ``n_parameter_violations`` (default ``2``) parameters
   fall outside their allowed range, or when the turning angle falls in the
   configured range.

.. list-table:: Default parameter plausibility ranges
   :header-rows: 1
   :widths: 45 25 30

   * - Parameter
     - Allowed range
     - Rule
   * - ``stride time [s]``
     - ``0.2`` -- ``3.0``
     - fail if outside
   * - ``gait velocity [m/s]``
     - ``0.2`` -- ``2.0``
     - fail if outside
   * - ``stride length [m]``
     - ``0.10`` -- ``1.5``
     - fail if outside
   * - ``abs(turning angle [deg])``
     - ``25`` -- ``90``
     - fail if **inside** this range
