What are DMOs?
==============

Digital Mobility Outcomes (DMOs) are quantitative descriptors of real-world
walking derived from wearable sensors. They span several levels of
granularity, from individual strides to day- and week-level summaries, and are
used to characterize physical activity and mobility outside the laboratory.

In gait analysis, the literature distinguishes between **micro** gait (stride-
level spatiotemporal parameters), **macro** gait (walking-bout structure and
complexity of the activity pattern over time), and patient-reported outcomes
(PROMs) with reported events. This pipeline focuses on micro and macro DMOs
derived from foot-worn IMUs.

Parameter families
------------------

The pipeline organizes DMOs into stride (micro) parameters and walking-bout /
day-level (macro) parameters.

.. note::

   **TODO:** insert the sunburst chart showing the division into stride (micro)
   parameters and macro parameters. Place the image in ``docs/_static/`` and
   reference it here, for example::

      .. image:: ../_static/dmos_sunburst.png
         :alt: DMO parameter families (sunburst)
         :align: center

The set of validated DMOs follows the gait-parameter taxonomy in the mobility
literature (e.g. Yarnall et al.). A full list of parameters, with units and
definitions, is maintained alongside the pipeline.

.. note::

   **TODO:** add the parameter table (validated DMOs, units, literature
   reference) and link it to the :doc:`../api` requirements.
