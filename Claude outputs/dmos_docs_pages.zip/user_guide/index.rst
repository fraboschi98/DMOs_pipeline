User guide
==========

This guide introduces the concepts behind the pipeline: what Digital Mobility
Outcomes are, the definitions and thresholds used to identify walking bouts,
pauses and breaks, and the end-to-end processing workflow.

.. toctree::
   :maxdepth: 2

   dmos
   definitions
   workflow
