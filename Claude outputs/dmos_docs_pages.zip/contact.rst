Contact
=======

DMOs Pipeline is developed within the dMed group.

* **Repository:** https://github.com/fraboschi98/DMOs_pipeline
* **Issues and questions:** please open an issue on the GitHub repository.

.. note::

   **TODO:** add the author list and affiliations, and, once the methodology
   paper is published, the citation and DOI so that users can cite the pipeline.
