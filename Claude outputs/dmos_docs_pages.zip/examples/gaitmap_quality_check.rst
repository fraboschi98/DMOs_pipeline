gaitmap + quality check + walking bouts
=======================================

This example runs the processing front end of the pipeline on a single
gaitmap-compatible IMU file:

#. load one gaitmap-compatible IMU signal;
#. run the gaitmap-based processing pipeline
   (:class:`~dmos_pipeline.gaitmap_pipeline.GaitMapPipeline`);
#. save gait events, stride-level parameters, and the processing log;
#. run quality control on the exported events and parameters
   (:class:`~dmos_pipeline.quality_check.QualityCheck`);
#. extract walking bouts, pauses, and signal breaks
   (:class:`~dmos_pipeline.wb_pipeline.WBpipeline`);
#. optionally plot every walking-bout pause
   (:class:`~dmos_pipeline.pause_plotter.PausePlotter`).

The ``gaitmap_config``, ``quality_check_config`` and ``wb_config`` dictionaries
at the top of the script hold the default thresholds documented in
:doc:`../user_guide/definitions`.

.. literalinclude:: ../../examples/main_gaitmap_quality_check.py
   :language: python
   :linenos:
