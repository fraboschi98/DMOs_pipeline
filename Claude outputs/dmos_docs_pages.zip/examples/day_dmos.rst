Day-level DMOs
==============

This example computes day-level Digital Mobility Outcomes from an existing
WB-level file (produced by :doc:`dmos_extraction`).

#. load the ``wb_parameters_average`` CSV file;
#. collect the corresponding logs
   (:class:`~dmos_pipeline.csv_collector.Collector`);
#. compute day-level DMOs, one row per patient and recording date
   (:class:`~dmos_pipeline.day_analyzer.DayLevel_analyzer`);
#. save the ``day_dmos`` table.

.. literalinclude:: ../../examples/main_day_dmos_analyisis.py
   :language: python
   :linenos:
