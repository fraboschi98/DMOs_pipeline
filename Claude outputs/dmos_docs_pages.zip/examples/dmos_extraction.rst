Walking-bout DMO extraction
===========================

This example collects the already-processed session outputs for one patient and
computes walking-bout-level average parameters.

#. collect processed outputs for one patient and a chosen set of dates
   (:class:`~dmos_pipeline.csv_collector.Collector`);
#. analyze the collected walking bouts and compute WB-level averages
   (:class:`~dmos_pipeline.wb_analyzer.WalkingBouts_analyzer`);
#. save the ``wb_parameters_average`` table used by the day-level, complexity,
   and KDE examples.

Dates can be selected as a single date, a list of dates, or ``"all"``.

.. literalinclude:: ../../examples/main_dmos_extraction.py
   :language: python
   :linenos:
