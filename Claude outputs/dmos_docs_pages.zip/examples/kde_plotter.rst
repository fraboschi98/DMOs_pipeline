KDE plots
=========

This example generates kernel-density-estimate (KDE) distribution plots of
WB-level gait parameters for one patient, starting from an existing
``wb_parameters_average`` file.

Optionally, the patient's ``day_dmos`` file can be loaded to exclude recording
dates with wearing time below a chosen threshold. Walking bouts are stratified
by ``WB_label``.

* ``date`` selects a single date, a list of dates, or ``"all"``;
* ``features`` selects a single feature, a list, or ``"all"`` default features.

.. literalinclude:: ../../examples/main_kdes_plotter.py
   :language: python
   :linenos:
