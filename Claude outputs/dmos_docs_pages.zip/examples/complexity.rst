Complexity metrics
==================

This example computes physical-activity (PA) complexity metrics from existing
WB-level files. It must be run after the WB-level analysis has created, for each
patient, a ``wb_parameters_average`` file containing the ``PA_state`` column
(``WalkingBouts_analyzer.add_pa_state_to_wb_dataframe("modified")``).

#. load each patient's WB-level file and collect the logs of the corresponding
   dates (:class:`~dmos_pipeline.csv_collector.Collector`);
#. use **one** :class:`~dmos_pipeline.complexity_analyzer.PAComplexity_analyzer`
   for all patients, so that the PLZC lag is chosen once (from the mean
   autocorrelation of all analyzed days) and values are comparable across
   patients;
#. save, in each patient's ``outputs_`` folder, the daily table, the weekly
   summary (with ``n_valid_days`` and the SampEn computed on the concatenated
   valid days), and the barcode figure of that patient's valid days.

.. note::

   The PLZC lag used for the whole analysis (``analyzer.plzc_lag_``) is printed,
   not saved as a column. Read it from the console output when comparing runs
   with a different set of patients or days.

.. literalinclude:: ../../examples/main_complexity.py
   :language: python
   :linenos:
