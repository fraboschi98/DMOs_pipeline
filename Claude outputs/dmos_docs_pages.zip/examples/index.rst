Examples
========

These examples mirror the scripts in the ``examples/`` folder of the
repository. They follow the natural order of the pipeline: from raw gaitmap
processing and quality control, through walking-bout and day-level DMO
extraction, to complexity metrics and KDE visualizations.

Each page includes the full script via ``literalinclude``, so it always
reflects the current code. Update the ``project_folder`` and ``signal_path``
paths to your own data before running.

.. toctree::
   :maxdepth: 1

   gaitmap_quality_check
   dmos_extraction
   day_dmos
   complexity
   kde_plotter

.. note::

   **TODO:** add result figures (WB detection, KDE) to ``docs/_static/`` and,
   where useful, provide the examples as Jupyter notebooks rendered in the docs.
