DMOs Pipeline
=============

**DMOs Pipeline** is a Python framework for deriving Digital Mobility Outcomes
(DMOs) from bilateral foot-worn IMU recordings in free-living / real-world
conditions. It takes stride-level gait events and parameters produced by an
already-validated algorithm (e.g. `gaitmap`), identifies walking bouts
following the Mobilise-D definition, and aggregates them into standardized
walking-bout-, day-, and week-level outcomes.

The package is built around object-oriented classes and a non-relational,
CSV/JSON data organization, so that each processing step can be run
independently or combined into an end-to-end pipeline, and custom algorithms
can be substituted at any stage.

Where to start
--------------

* :doc:`overview` --- what the pipeline is, how to install it, how to cite it.
* :doc:`user_guide/index` --- DMO concepts, the walking-bout / pause / break
  definitions, and the processing workflow.
* :doc:`examples/index` --- runnable scripts, from gaitmap + quality check to
  day-level DMOs and KDE plots.
* :doc:`api` --- all pipeline classes, grouped by processing stage.

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Getting started

   overview

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: User guide

   user_guide/index

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Examples

   examples/index

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Reference

   api
   changelog
   contact
